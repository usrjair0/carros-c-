﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carro2
{
    class Carro
    {
        //public => modificador de acesso

        public double potencia; //atributos
        public int numeroDePortas;
        public string cor;
        public string nome;
        public int velocidade;

        public void acelerar()
        {
            this.velocidade++;
        }

        public void frear() // método
        {
            this.velocidade--;
        }

        public Carro() //método construtor. //Deve ter o mesmo nome da Classe. //Importante: Definir os valores padrões.
        {
            this.potencia = 0;
            this.numeroDePortas = 2;
            this.cor = string.Empty;
            this.nome = "";
            this.velocidade = 0;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            //ferrari => variável => objeto (recebe um endereço de memória - heap)            
            Carro ferrari = new Carro();  //new => palavra reservada do C# para invocar o método construtor
                        
            Carro carro2 = new Carro();
            
            List<Carro> carros = new List<Carro>();

            for (int i = 0; i < 3; i++)
            {
                Carro carro = new Carro();
                carros.Add(carro);
            }

            ferrari.nome = "Ferrari do Zequinha";

            carros[2].nome = "Fusca";

            carros[1].nome = ferrari.nome;

            carros[2] = carro2;

            carros[2].nome = "Chevete";

            carro2.nome = "Celtinha Chiqueirinho";
        }
    }
}
