﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Carro01
{
    
    struct Carro
    {
        public double potencia;
        public int numeroDePortas;
        public string cor;
        public string nome;
        public int velocidade;

        /*public Carro(double potencia, int numeroDePortas, string cor, string nome, int velocidade)
        {
            this.potencia = potencia;
            this.numeroDePortas = numeroDePortas;
            this.cor = cor;
            this.nome = nome;
            this.velocidade = velocidade;    
        }*/

        public void acelerar()
        {
            this.velocidade++;
        }

        public void frear()
        {
            this.velocidade--;
        }

    }

    internal class Program
    {
        static void Main(string[] args)
        {
            #region "Variáveis"
            
            double carro1Potencia = 1.4;
            int carro1NumeroDePortas = 2;
            string carro1Cor = "branca";
            string carro1Nome = "gol";

            double carro2Potencia = 1.6;
            int carro2NumeroDePortas = 4;
            string carro2Cor = "vermelha";
            string carro2Nome = "ferrari";

            #endregion

            #region "Listas"

            List<double> potencias = new List<double>();
            potencias.Add(1.4);
            potencias.Add(1.6);

            List<int> numerosDePortas = new List<int>();
            numerosDePortas.Add(2);
            numerosDePortas.Add(4);

            List<string> cores = new List<string>();
            cores.Add("branca");
            cores.Add("Vermelha");

            List<string> nomes = new List<string>();
            nomes.Add("gol");
            nomes.Add("ferrari");

            #endregion

            #region "Estrutura"

            Carro carro1;
            carro1.potencia = 1.4;
            carro1.numeroDePortas = 2;
            carro1.cor = "branca";
            carro1.nome = "gol";
            carro1.velocidade = 10;


            Carro carro2 = new Carro();
            carro2.potencia = 1.6;
            carro2.numeroDePortas = 4;
            carro2.cor = "vermelha";
            carro2.nome = "ferrari";
            carro2.acelerar();

            Carro carro3 = carro2;
            carro3.nome = "Fusca";

            carro1.acelerar();
            
            carro3.acelerar();

            
            List<Carro> carros = new List<Carro>();

            for (int i = 0; i < 5; i++)
            {
                Carro carro = new Carro();
                carro.nome = "Ferrari";
                carro.potencia = 1.6;
                carro.numeroDePortas = 2;
                carro.cor = "vermelha";
                                
                carros.Add(carro);
            }
            

            #endregion

          

        }
    }
}
